// Only the unused legacy plan Decimal helper needs this runtime import in this test.
export const Prisma = { Decimal: class { constructor() { throw new Error('Plan price conversion is outside this joint test'); } } };
