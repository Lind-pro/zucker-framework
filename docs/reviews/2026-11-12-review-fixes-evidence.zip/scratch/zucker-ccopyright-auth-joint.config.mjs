import base from '/tmp/zucker-auth-review.config.mjs';
import {createRequire} from 'node:module';
const root = '/Users/lind/Documents/projects/zucker-framework';
const req = createRequire(root+'/package.json');
export default { ...base, resolve: { ...base.resolve, alias: [...base.resolve.alias,
  {find:/^vitest$/,replacement:req.resolve('vitest').replace(/index\.cjs$/, 'dist/index.js')},
  {find:/^@\//,replacement:'/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/'},
]}, test: {...base.test, include:['/tmp/zucker-ccopyright-auth-joint.spec.ts']} };
