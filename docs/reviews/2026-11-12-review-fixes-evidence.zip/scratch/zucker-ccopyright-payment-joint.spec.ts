// Actual migrate/framework storage options and adapter; generated Prisma delegates are a PGlite
// facade. This proves the product/Framework boundary, not the generated client or server sockets.
import { PGlite } from '@electric-sql/pglite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { SubscriptionAssignmentService } from '@zucker-framework/payment';
import { createUserSubscriptionStore, resolveSubscriptionsStorage } from '@zucker-framework/back-office/subscriptions';
import { isActiveTerm } from '@zucker-framework/credit';
import { CopyrightDatabase, FRAMEWORK_MODEL_ALIASES } from '/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/infrastructure/database/framework-database';
import { COPYRIGHT_SUBSCRIPTIONS_STORAGE, copyrightSubscriptionsOptions } from '/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/modules/subscriptions/subscriptions.host';
import { PgTestAdapter } from '/Users/lind/Documents/projects/zucker-framework/packages/back-office/src/subscriptions/testing/pg-test-adapter';

function client(pg: Pick<PGlite, 'query'>, transaction?: PGlite['transaction']) {
  const adapter = new PgTestAdapter({ async query(sql, values) {
    const result = await pg.query<Record<string, unknown>>(sql, values);
    return { rows: result.rows, rowCount: result.affectedRows ?? null };
  } }, true);
  return { subscriptionPlan: adapter.model('subscription_plans'),
    userSubscription: adapter.model('user_subscriptions'), userSubscriptionPayment: adapter.model('user_subscription_payments'),
    $queryRawUnsafe: async (sql: string, ...values: unknown[]) => (await pg.query(sql, values)).rows,
    $transaction: (work: (tx: unknown) => Promise<unknown>) => {
      if (!transaction) throw new Error('Unexpected nested transaction');
      return transaction(tx => work(client(tx)));
    },
  };
}

describe('ccopyright Phase 2 payment writer with unreleased Framework fixes', () => {
  let pg: PGlite, db: CopyrightDatabase;
  const now = new Date('2026-11-01T00:00:00Z');
  const input = { userId: 'synthetic-owner', planId: 'synthetic-plan', reference: 'cycle:synthetic-cycle',
    billingCycle: 'MONTHLY' as const, periodStart: now, periodEnd: new Date('2026-12-01T00:00:00Z') };
  const storage = resolveSubscriptionsStorage(COPYRIGHT_SUBSCRIPTIONS_STORAGE);
  beforeAll(async () => {
    pg = await PGlite.create();
    await pg.exec(`
      CREATE TABLE subscription_plans (id text PRIMARY KEY, slug text UNIQUE, status boolean);
      CREATE TABLE user_subscriptions (id text PRIMARY KEY DEFAULT gen_random_uuid()::text, "userId" text NOT NULL UNIQUE,
        "planId" text NOT NULL, status text NOT NULL, "billingCycle" text NOT NULL, "startDate" timestamptz NOT NULL,
        "endDate" timestamptz, "cancelAtPeriodEnd" boolean NOT NULL, "canceledAt" timestamptz, source text NOT NULL,
        "paymentReference" text, "createdAt" timestamptz DEFAULT now(), "updatedAt" timestamptz DEFAULT now());
      CREATE TABLE user_subscription_payments (id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
        reference text NOT NULL UNIQUE, "userId" text NOT NULL, "planId" text NOT NULL, "billingCycle" text NOT NULL,
        "periodStart" timestamptz NOT NULL, "periodEnd" timestamptz, "orderId" text);
      INSERT INTO subscription_plans VALUES ('synthetic-plan','professional',true);
    `);
    db = new CopyrightDatabase(client(pg, pg.transaction.bind(pg)) as never);
  }, 30_000);
  afterAll(async () => { await pg?.close(); });
  const writer = (tx: Parameters<typeof createUserSubscriptionStore>[0]) => new SubscriptionAssignmentService(
    createUserSubscriptionStore(tx, storage, { transaction: tx, now: () => now }), { now: () => now, activeTerm: isActiveTerm });

  it('keeps actual Phase 2 direct payment + replay independent of future outbox schema', async () => {
    expect(FRAMEWORK_MODEL_ALIASES).not.toHaveProperty('billingOutbox');
    expect(copyrightSubscriptionsOptions().features?.paymentWriteBack).toBe(false);
    await db.transaction(async tx => {
      expect((await writer(tx).recordPayment(input)).outcome).toBe('applied');
      expect((await writer(tx).recordPayment(input)).outcome).toBe('replayed');
    });
    expect((await pg.query('SELECT count(*)::int AS n FROM user_subscription_payments')).rows).toEqual([{ n: 1 }]);
    expect((await pg.query('SELECT "paymentReference",status FROM user_subscriptions')).rows)
      .toEqual([{ paymentReference: input.reference, status: 'ACTIVE' }]);
  });

  it('rolls payment evidence back with the product billing transaction', async () => {
    await expect(db.transaction(async tx => {
      await writer(tx).recordPayment({ ...input, reference: 'cycle:rollback' });
      throw new Error('synthetic product failure');
    })).rejects.toThrow('synthetic product failure');
    expect((await pg.query('SELECT reference FROM user_subscription_payments ORDER BY reference')).rows)
      .toEqual([{ reference: input.reference }]);
  });

  it('refuses refund grant mutation until Phase 3 binds durable application history', async () => {
    await expect(db.transaction(tx => writer(tx).revokePayment({ userId: input.userId, reference: input.reference })))
      .rejects.toMatchObject({ reason: 'unavailable' });
    expect((await pg.query('SELECT status FROM user_subscriptions')).rows).toEqual([{ status: 'ACTIVE' }]);
  });
});
