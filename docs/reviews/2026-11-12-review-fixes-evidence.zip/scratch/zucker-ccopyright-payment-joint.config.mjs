import base from '/tmp/zucker-ccopyright-auth-joint.config.mjs';
export default {...base, resolve:{...base.resolve,alias:[...base.resolve.alias,
 {find:/^@prisma\/client$/,replacement:'/tmp/zucker-ccopyright-prisma-stub.ts'},
 {find:/^@zucker-ccopyright\/shared$/,replacement:'/tmp/zucker-ccopyright-joint-dac278e/packages/shared/src/index.ts'},
]},test:{...base.test,environment:'node',include:['/tmp/zucker-ccopyright-payment-joint.spec.ts']}};
