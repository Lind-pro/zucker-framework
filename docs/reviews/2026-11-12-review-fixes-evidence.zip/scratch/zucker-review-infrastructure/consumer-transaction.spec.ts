import { CopyrightDatabase, TRANSACTION_LIMITS } from '/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/infrastructure/database/framework-database.ts';
import { PrismaCrudService } from '/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/infrastructure/database/prisma-crud.service.ts';
import { DynamicQueryService, DynamicQueryParamService, FilterOperatorFactory, ALL_OPERATORS } from '/Users/lind/Documents/projects/zucker-framework/packages/crud/src/index.ts';

vi.mock('/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/infrastructure/database/prisma.service.ts', () => ({ PrismaService: class PrismaService {} }));

it('actual ccopyright PrismaCrudService dynamic reads share CopyrightDatabase transactions', async () => {
  const row = { id: 'synthetic-ledger', name: 'pending' };
  const root = { findUnique: vi.fn(async () => null), findMany: vi.fn(async () => []), count: vi.fn(async () => 0) };
  const tx = { create: vi.fn(async () => row), findUnique: vi.fn(async () => row), findMany: vi.fn(async () => [row]), count: vi.fn(async () => 1) };
  const prisma = { paymentRecord: root, aIModel: root,
    $transaction: vi.fn(async (work: (client: unknown) => unknown) => work({ paymentRecord: tx, aIModel: tx })) };
  const shared = new CopyrightDatabase(prisma as never);
  const queries = new DynamicQueryService(shared, new DynamicQueryParamService(new FilterOperatorFactory(ALL_OPERATORS.map(Op => new Op()))));
  class ProductLedger extends PrismaCrudService<{ id: string }> {}
  const service = new ProductLedger(prisma as never, shared, queries, 'paymentRecord');
  await expect(service.transaction(async () => {
    await service.create(row);
    expect(await service.findOne(row.id)).toEqual(row);
    expect((await service.findAll({ page: 1 })).data).toEqual([row]);
    expect(await service.countByQuery({})).toBe(1);
    expect(await service.exists({})).toBe(true);
    expect(await queries.findOne('paymentRecord', row.id)).toEqual(row);
    throw new Error('synthetic rollback');
  })).rejects.toThrow('synthetic rollback');
  expect(root.findMany).not.toHaveBeenCalled();
  expect(prisma.$transaction).toHaveBeenCalledWith(expect.any(Function), TRANSACTION_LIMITS);
  expect((await service.findAll({})).data).toEqual([]);
});
