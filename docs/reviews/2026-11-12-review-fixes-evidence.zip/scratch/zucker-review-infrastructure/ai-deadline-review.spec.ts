import { expect, it, vi } from 'vitest';
import { AITaskService } from '/Users/lind/Documents/projects/zucker-framework/packages/ai-tasks/src/ai-task.service';
import { FAKE_PNG_BASE64 } from '/Users/lind/Documents/projects/zucker-framework/packages/ai/src/testing';

it('does not begin an output write after its deadline expires while renewing a lease', async () => {
  let release!: () => void;
  const lease = new Promise<void>(resolve => { release = resolve; });
  const put = vi.fn(async () => ({ storageKey: 'should-not-exist' }));
  const service = new AITaskService({ outputs: { put }, outputLimits: { downloadTimeoutMs: 15 } } as any) as any;
  const context = { signal: new AbortController().signal, assertActive: () => lease };
  const work = service.withOutputDeadline(context, (bounded: any) => service.rehostBuffered(
    bounded, { id: 'task', ownerId: 'owner', kind: 'image' }, 0, { base64: FAKE_PNG_BASE64 },
    { fetch: vi.fn(), maxBytes: 1024, allowedContentTypes: ['image/png'], signal: bounded.signal }, 1, true,
  ));
  await expect(work).rejects.toMatchObject({ code: 'AI_OUTPUT_TIMEOUT' });
  release();
  await new Promise(resolve => setTimeout(resolve, 0));
  expect(put).not.toHaveBeenCalled();
});
