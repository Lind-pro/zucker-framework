import base from '/Users/lind/Documents/projects/zucker-framework/vitest.config.ts';
export default { ...base, test: { ...base.test, environment: 'node',
  include: ['/tmp/zucker-review-infrastructure/ai-deadline-review.spec.ts'],
  setupFiles: ['/Users/lind/Documents/projects/zucker-framework/vitest.setup.ts'],
} };
