const ts=require('/Users/lind/Documents/projects/zucker-framework/node_modules/typescript');
const fs=require('node:fs');
const {createRequire}=require('node:module');
const root='/Users/lind/Documents/projects/zucker-framework';
const server=createRequire(root+'/templates/server/package.json');
const paths={};
for(const name of fs.readdirSync(root+'/packages')) {
 const dir=root+'/packages/'+name;
 if(!fs.existsSync(dir+'/package.json'))continue;
 const pkg=JSON.parse(fs.readFileSync(dir+'/package.json','utf8'));
 for(const key of Object.keys(pkg.exports||{'.':{}})) {
  if(key==='./package.json')continue;
  const candidates=key==='.'?['src/index.ts']:[`src/${key.slice(2)}/index.ts`,`src/${key.slice(2)}.ts`];
  const file=candidates.find(file=>fs.existsSync(dir+'/'+file));
  if(file)paths[pkg.name+(key==='.'?'':key.slice(1))]=[dir+'/'+file];
 }
}
for(const name of ['@nestjs/common','@nestjs/core','@nestjs/jwt','@nestjs/event-emitter'])paths[name]=[server.resolve(name).replace(/index\.js$/,'index.d.ts')];
paths['@electric-sql/pglite']=[root+'/packages/credit/node_modules/@electric-sql/pglite/dist/index.d.ts'];
const files=process.argv.slice(2).map(f=>root+'/'+f);
const cfg=ts.readConfigFile(root+'/tsconfig.base.json',ts.sys.readFile).config;
const parsed=ts.parseJsonConfigFileContent(cfg,ts.sys,root);
const program=ts.createProgram(files,{...parsed.options,noEmit:true,rootDir:root,paths});
const diagnostics=ts.getPreEmitDiagnostics(program);
const own=diagnostics.filter(d=>!d.file||files.includes(d.file.fileName));
for(const d of own)console.log(ts.formatDiagnosticsWithColorAndContext([d],{getCanonicalFileName:f=>f,getCurrentDirectory:()=>root,getNewLine:()=> '\n'}));
console.log(JSON.stringify({ownedDiagnostics:own.length,totalDependencyDiagnostics:diagnostics.length}));
process.exitCode=own.length?1:0;
