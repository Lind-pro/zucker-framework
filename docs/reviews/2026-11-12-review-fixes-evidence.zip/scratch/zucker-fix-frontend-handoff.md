# R09 / R10 / R19 修复与消费者核对

工作区：`/Users/lind/Documents/projects/zucker-framework`，未 commit/push/build/install。

## 已实现

- R09：`templates/web/src/lib/account-session.ts:23` 复用 `createCookieSession`，主 client 与 shell 都使用 `guardedRefresh` 和 `acceptsSessionToken`；请求绑定账户作用域，换账户会取消旧 Axios/SSE 请求。显式登录/OAuth 使用单次账户查询并原子采用 token/user/permissions。旧的 `auth-storage` key/持久化形状保持兼容，增加 summary 写入保护防止旧标签覆盖新账户。主 client 的同类历史缺陷一并处理。
- R10：`templates/web/src/app/api/revalidate/route.ts:11` 按流实际累计字节，超过 16 KiB 立即 cancel 并 413，不再先完整读取。合法签名、禁用行为和重放保护保留。
- R19：`templates/web/src/features/inbox/inbox-state.ts:49` 单条标已读后把页面限制在剩余页数，真实组件 effect 拉取上一页。21 条未读、第二页唯一一条被标已读后显示第一页 20 条。
- `packages/fe-auth/src/cookie-session.ts:122` summary 类型只要求运行时确实调用的 `allowIdentityChange`；typed summary 可直接传入。没有新增运行时 export。库现有 cookie-session 测试辅助器使用 typed summary，去掉 as never；README 说明契约。
- 新增 `vitest.web.config.ts` 和 `templates/web/test/{account-session,revalidate-route,inbox-pagination}.spec.*`。Root 已增加 test:web；沿用现有 Vitest/JSDOM/Testing Library，未加依赖。模板 tsconfig 排除 test 目录。

## 验证

| 检查 | 结果 | 证据 |
| --- | --- | --- |
| Web 真实模块/组件 Vitest | 3 文件 14/14 passed | `/tmp/zucker-fix-web-final.log` |
| fe-auth session/cookie-session + fe-admin restore/focus | 4 文件 39/39 passed | `/tmp/zucker-fix-session-regressions.log` |
| typed summary 辅助器修改后 cookie-session 重跑 | 13/13 passed（已计入上述39，不重复累计） | `/tmp/zucker-fix-cookie-summary-final.log` |
| 原 Node inbox/sign-in-flow | 13/13 passed | `/tmp/zucker-fix-web-node.log` |
| Web ESLint9 定向源文件/测试 | passed | `/tmp/zucker-fix-web-eslint.log` |
| 源码别名定向 noEmit（含修改的 cookie-session spec） | passed | `/tmp/zucker-web-fixes-typecheck.json`、`.log` |
| git diff --check 负责范围 | passed | 命令输出无错误 |

普通模板 `tsc -p templates/web/tsconfig.json` **未通过**：旧 `.next` route validator 引用已移动路由、qrcode-generator 未安装、fe-blocks dist 缺失；同时 fe-auth 仍解析旧 dist 的 summary 类型。没有用新源码验证结果冒充产物验证；新源码别名 noEmit 已通过。仍需以后授权的正确产物/环境验证。`/tmp/zucker-fix-web-typecheck-final.log`。

## ccopyright migrate/framework 联测

来源是 root 获取的 `/tmp/zucker-ccopyright-joint-dac278e` 快照（dac278e）；未改消费者源代码。Landing 包 manifest 中 fe-auth/fe-http-client/fe-storage 为 1.0.21；Admin fe-admin/fe-auth/fe-http-client 等为 1.0.21。

- Landing `apps/landing/features/auth/session.ts:76` 已经使用 createCookieSession；`:91` 登录采用原子 adoptToken。
- Landing `apps/landing/lib/http-client.ts:45` 用 guardedRefresh，`:49` 使用 acceptsSessionToken，`:69` 给请求绑定账户取消 signal。因此 R09 的模板接线不应重复抄入该消费者。
- Landing `apps/landing/features/auth/state.ts:15` summary guard，`:21` token-free partialize；它与 Web 旧兼容存储策略不同，保留消费者自己的持久化策略。
- Admin `apps/admin/src/admin.tsx:34` 使用 createAdminApp，`:39` 启用 reloadOnFocus，`:61` 调工厂；Framework fe-admin 内已有同类 guard。消费者无需新增第二套 auth。

可复现 harness：运行 `node /tmp/zucker-ccopyright-joint-browser-prepare.mjs`，再执行 `node --test /tmp/zucker-ccopyright-joint-dac278e/apps/landing/tests/account-session.framework-source.browser.mjs`。保留消费者原 12 例，增加 A 请求不能借 B cookie refresh 重放、A 待处理 mutation 在显式切 B 后取消两例（`:287`、`:307`）。全请求由 Playwright route 合成拦截，esbuild write:false，没有 Next/server、端口监听或真实 provider。

源码 alias 使用当前 Framework 的 fe-auth/fe-http-client/fe-storage；React/ReactDOM 统一使用19.2.8。消费者依赖不完整，harness 对缺失 UI 依赖使用已安装 Framework 的 @radix-ui/react-slot1.2.3、sonner2.0.8、clsx2.1.1、tailwind-merge3.6.0，精确路径在 `/tmp/zucker-ccopyright-joint-browser-provenance.json`。这不是消费锁文件精确依赖验收。

**浏览器仍阻塞，0 条断言执行**：内存编译成功；默认 Playwright headless_shell-1234 不存在（`/tmp/zucker-ccopyright-joint-browser.log`）。通过 CHROMIUM_EXECUTABLE 指定已安装 Google Chrome 后启动进程 SIGABRT，清理日志 kill EPERM（`/tmp/zucker-ccopyright-joint-browser-chrome.log`）。14例全因 before hook失败；不能算14个产品缺陷，也不能报浏览器通过。未安装浏览器/依赖、未申请越权，进程退出、临时profile已由Playwright清理。

## 迁移与回滚

无数据库/持久化迁移；Web保留原key及形状。跨账户cookie刷新现在拒绝并要求重新登录；显式登录仍可切换账户。既有消费者不会自动获得模板修复，须分别核对其接线；ccopyright 已具备相应保护。fe-auth 类型修正与模板需以后新的不可变发布产物，当前source alias不是发布包替代品。回滚相应源文件即可，不需数据回滚；会重新暴露三个原问题。
