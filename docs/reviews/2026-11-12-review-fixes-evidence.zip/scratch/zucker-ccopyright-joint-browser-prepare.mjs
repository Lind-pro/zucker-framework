import { existsSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createRequire } from 'node:module';

const framework = process.env.FRAMEWORK_ROOT || '/Users/lind/Documents/projects/zucker-framework';
const consumer = process.env.CCOPYRIGHT_ROOT || '/tmp/zucker-ccopyright-joint-dac278e';
const require = createRequire(resolve(framework, 'package.json'));
const input = resolve(consumer, 'apps/landing/tests/account-session.browser.mjs');
const output = resolve(consumer, 'apps/landing/tests/account-session.framework-source.browser.mjs');
const alias = {
  '@': resolve(consumer, 'apps/landing'),
  'react': dirname(require.resolve('react/package.json')),
  'react-dom': dirname(require.resolve('react-dom/package.json')),
  ...Object.fromEntries(['fe-auth', 'fe-http-client', 'fe-storage'].map(name => [
    `@zucker-framework/${name}`, resolve(framework, `packages/${name}/src/index.ts`),
  ])),
};
// This checkout's consumer dependency links are incomplete. Reuse installed UI dependencies
// solely in this synthetic source harness, recording their exact paths/versions below.
const uiDependencyVersions = {};
for (const name of ['@radix-ui/react-slot', 'sonner', 'clsx', 'tailwind-merge']) {
  const store = resolve(framework, 'node_modules/.pnpm');
  const manifest = readdirSync(store).filter(entry => entry.startsWith(name.replace('/', '+') + '@')).sort()
    .map(entry => resolve(store, entry, 'node_modules', name, 'package.json')).find(existsSync);
  if (!manifest) throw new Error(`Installed dependency unavailable: ${name}`);
  alias[name] = dirname(manifest);
  uiDependencyVersions[name] = JSON.parse(readFileSync(manifest, 'utf8')).version;
}
let source = readFileSync(input, 'utf8')
  .replace("import { chromium } from 'playwright'", `const frameworkRequire = createRequire(${JSON.stringify(resolve(framework, 'package.json'))})\nconst { chromium } = frameworkRequire('@playwright/test')`)
  .replace("const { build } = createRequire(require.resolve('vite', { paths: [resolve(root, 'apps/admin')] }))('esbuild')", "const { build } = createRequire(createRequire(frameworkRequire.resolve('vitest')).resolve('vite'))('esbuild')")
  .replace("alias: { '@': app },", `alias: ${JSON.stringify(alias)},`);

source += `
test('a shared refresh cookie for account B never replays account A requests as B', async t => {
  const ctx = await context(t, { 'cc-account-session': summary('A') })
  let calls = 0
  await ctx.route('**/api/authorize/refresh', route => route.fulfill({ json: envelope({ access_token: jwt(++calls === 1 ? 'A' : 'B', calls === 1 ? 'A-session' : 'B-session', 2) }) }))
  const page = await open(ctx, '/login')
  const requestTokens = []
  await page.route('**/api/identity-probe', route => {
    requestTokens.push(route.request().headers().authorization)
    return route.fulfill({ status: 401, json: { message: 'expired' } })
  })
  const result = await page.evaluate(() => consumer.httpClient.post('/identity-probe', { originalAccount: 'A' }).then(() => 'succeeded', e => e.status))
  assert.equal(result, 401)
  assert.equal(calls, 2)
  assert.deepEqual(requestTokens, [\`Bearer \${jwt('A', 'A-session', 2)}\`])
  const state = await page.evaluate(() => consumer.store.getState())
  assert.equal(state.isAuthenticated, false)
  assert.equal(state.token, null)
  assert.equal(state.user, null)
})

test('a late mutation from account A is cancelled when this tab explicitly signs in as B', async t => {
  const ctx = await context(t, { 'cc-account-session': summary('A') })
  let refreshes = 0
  await ctx.route('**/api/authorize/refresh', route => { refreshes++; return route.fulfill({ json: envelope({ access_token: jwt('A', 'A-session', 2) }) }) })
  const page = await open(ctx, '/login')
  let release, started
  const ready = new Promise(resolve => { started = resolve })
  const gate = new Promise(resolve => { release = resolve })
  const tokens = []
  await page.route('**/api/late-mutation', async route => {
    tokens.push(route.request().headers().authorization)
    started()
    await gate
    await route.fulfill({ status: 401, json: { message: 'expired' } }).catch(() => {})
  })
  await page.evaluate(() => { window.pendingMutation = consumer.httpClient.post('/late-mutation', { originalAccount: 'A' }).then(() => 'succeeded', e => e.code) })
  await ready
  await page.evaluate(token => consumer.cookieSession.adoptToken(token), jwt('B', 'B-session', 1))
  release()
  assert.equal(await page.evaluate(() => window.pendingMutation), 'ERR_CANCELED')
  assert.equal(refreshes, 1)
  assert.equal(tokens.length, 1)
  const state = await page.evaluate(() => consumer.store.getState())
  assert.equal(state.user.id, 'B')
  assert.equal(state.token, jwt('B', 'B-session', 1))
})
`;
writeFileSync(output, source);
console.log(JSON.stringify({ input, output, frameworkSources: alias, uiDependencyVersions }, null, 2));
