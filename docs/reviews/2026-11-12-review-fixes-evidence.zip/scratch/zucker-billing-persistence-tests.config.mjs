import { createRequire } from 'node:module';
import base from '/Users/lind/Documents/projects/zucker-framework/vitest.config.ts';
const require = createRequire('/Users/lind/Documents/projects/zucker-framework/templates/server/package.json');
export default { ...base, resolve: { ...base.resolve, alias: [
  ...['@nestjs/common','@nestjs/common/constants','@nestjs/core','@nestjs/jwt','@nestjs/event-emitter'].map(name => ({find:new RegExp(`^${name}$`),replacement:require.resolve(name)})),
  { find: /^@electric-sql\/pglite$/, replacement: createRequire('/Users/lind/Documents/projects/zucker-framework/packages/credit/package.json').resolve('@electric-sql/pglite') },
  ...base.resolve.alias,
] } };
