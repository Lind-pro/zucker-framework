/* global consumer: readonly */
// Landing cookie session against the Framework account host (`/authorize/*`), with synthetic routes.
// Real store, HTTP client, cookie session, legacy upgrade and forms; every other request is refused.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { resolve } from 'node:path'
import { after, before, test } from 'node:test'
const frameworkRequire = createRequire("/Users/lind/Documents/projects/zucker-framework/package.json")
const { chromium } = frameworkRequire('@playwright/test')
const require = createRequire(import.meta.url)
const root = resolve(import.meta.dirname, '../../..')
const app = resolve(root, 'apps/landing')
const { build } = createRequire(createRequire(frameworkRequire.resolve('vitest')).resolve('vite'))('esbuild')
const bundled = await build({
  stdin: { resolveDir: app, loader: 'tsx', contents: `
    import React from 'react'; import { createRoot } from 'react-dom/client';
    import store, { SESSION_PERSIST_KEY } from './features/auth/state';
    import { httpClient } from './lib/http-client';
    import { bootSession, cookieSession } from './features/auth/session';
    import { AccountPage } from './features/auth/components/AccountPage';
    import { ForgotPasswordForm } from './features/auth/components/ForgotPasswordForm';
    import { LoginForm } from './features/auth/components/LoginForm';
    import { AuthSessionSync } from './features/auth/components/AuthSessionSync';
    const root = createRoot(document.getElementById('root'));
    window.consumer = { store, httpClient, bootSession, cookieSession, persistKey: SESSION_PERSIST_KEY,
      mount: view => root.render(<><AuthSessionSync />{view === 'account' ? <AccountPage /> : view === 'forgot' ? <ForgotPasswordForm /> : view === 'login' ? <LoginForm /> : null}</>) };
  ` }, bundle: true, write: false, platform: 'browser', format: 'iife', jsx: 'automatic',
  alias: {"@":"/tmp/zucker-ccopyright-joint-dac278e/apps/landing","react":"/Users/lind/Documents/projects/zucker-framework/node_modules/.pnpm/react@19.2.8/node_modules/react","react-dom":"/Users/lind/Documents/projects/zucker-framework/node_modules/.pnpm/react-dom@19.2.8_react@19.2.8/node_modules/react-dom","@zucker-framework/fe-auth":"/Users/lind/Documents/projects/zucker-framework/packages/fe-auth/src/index.ts","@zucker-framework/fe-http-client":"/Users/lind/Documents/projects/zucker-framework/packages/fe-http-client/src/index.ts","@zucker-framework/fe-storage":"/Users/lind/Documents/projects/zucker-framework/packages/fe-storage/src/index.ts","@radix-ui/react-slot":"/Users/lind/Documents/projects/zucker-framework/node_modules/.pnpm/@radix-ui+react-slot@1.2.3_@types+react@19.2.18_react@19.2.8/node_modules/@radix-ui/react-slot","sonner":"/Users/lind/Documents/projects/zucker-framework/node_modules/.pnpm/sonner@2.0.8_@types+react@19.2.18_react-dom@19.2.8_react@19.2.8__react@19.2.8/node_modules/sonner","clsx":"/Users/lind/Documents/projects/zucker-framework/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx","tailwind-merge":"/Users/lind/Documents/projects/zucker-framework/node_modules/.pnpm/tailwind-merge@3.6.0/node_modules/tailwind-merge"}, nodePaths: [resolve(app, 'node_modules')],
  define: { 'process.env.NODE_ENV': '"test"', 'process.env.NEXT_PUBLIC_API_BASE_URL': 'undefined' },
  plugins: [{ name: 'synthetic-router', setup(build) {
    build.onResolve({ filter: /^next\/(navigation|link)$/ }, ({ path }) => ({ path, namespace: 'router' }))
    build.onLoad({ filter: /.*/, namespace: 'router' }, ({ path }) => ({ resolveDir: app, contents: path.endsWith('navigation')
      ? `const router = { push(path) { window.__redirect = path }, replace(path) { window.__redirect = path }, refresh() {} }; export const useRouter = () => router; export const useSearchParams = () => new URLSearchParams(location.search); export const usePathname = () => location.pathname;`
      : `import React from 'react'; export default function Link(props) { return React.createElement('a', props); }` }))
  } }],
})
// localhost is a secure context, so navigator.locks (the cross-tab refresh lock) is available.
const origin = 'http://localhost:45873'
const jwt = (sub, sid, serial = 1) => `${Buffer.from('{}').toString('base64url')}.${Buffer.from(JSON.stringify({ sub, sid, serial, tokenUse: 'access' })).toString('base64url')}.synthetic`
const me = (id = 'A') => ({ id, username: id, name: `账户${id}`, email: `${id}@example.test`, emailVerified: true, typeId: 'user', permissions: [{ id: 'software', actions: ['read'] }] })
const summary = (id = 'A') => JSON.stringify({ state: { isAuthenticated: true, user: { id, username: id, name: `账户${id}`, email: `${id}@example.test` }, permissions: [] }, version: 0 })
const legacy = (id = 'A') => JSON.stringify({ state: { isAuthenticated: true, token: `legacy-access-${id}`, refreshToken: `legacy-refresh-${id}`, user: { id, username: id }, permissions: [] }, version: 0 })
const envelope = result => ({ status: 200, message: 'success', result })
const session = (id = 'A', serial = 1) => ({ userId: id, token: jwt(id, `${id}-session`, serial), expires: 900000 })

let browser
before(async () => { browser = await chromium.launch({ headless: true, ...(process.env.CHROMIUM_EXECUTABLE ? { executablePath: process.env.CHROMIUM_EXECUTABLE } : {}) }) })
after(async () => browser?.close())

async function context(t, storage = {}) {
  const ctx = await browser.newContext()
  t.after(() => ctx.close())
  await ctx.route('**/*', route => {
    const url = new URL(route.request().url())
    if (url.origin !== origin) return route.abort('blockedbyclient')
    return url.pathname.startsWith('/api/') ? route.fulfill({ status: 404, json: { message: 'Unknown synthetic route' } }) : route.fulfill({ contentType: 'text/html', body: '<div id="root"></div>' })
  })
  await ctx.route('**/api/authorize/me', route => {
    const token = route.request().headers().authorization?.replace('Bearer ', '') ?? ''
    const sub = JSON.parse(Buffer.from(token.split('.')[1] ?? 'e30', 'base64url').toString() || '{}').sub
    return sub ? route.fulfill({ json: envelope(me(sub)) }) : route.fulfill({ status: 401, json: { message: 'Unauthorized' } })
  })
  ctx.seed = storage
  return ctx
}
async function open(ctx, path = '/login', { boot = true } = {}) {
  const page = await ctx.newPage()
  page.setDefaultTimeout(7000)
  await page.goto(`${origin}${path}`)
  await page.evaluate(seed => { for (const [key, value] of Object.entries(seed)) if (localStorage.getItem(key) === null) localStorage.setItem(key, value) }, ctx.seed)
  ctx.seed = {}
  await page.addScriptTag({ content: bundled.outputFiles[0].text })
  if (boot) await page.evaluate(() => consumer.bootSession())
  return page
}
const credentialsLeft = page => page.evaluate(() => ({
  storage: Object.keys(localStorage).filter(key => /legacy-|eyJ/.test(localStorage.getItem(key) ?? '') || ['auth-storage', 'AUTH_TOKEN', 'REFRESH_TOKEN'].includes(key)),
  cookies: document.cookie,
  persisted: localStorage.getItem(consumer.persistKey),
}))

test('legacy tokens are upgraded once into a cookie session and removed from script storage', async t => {
  const ctx = await context(t, { 'auth-storage': legacy() })
  const bodies = []
  await ctx.route('**/api/authorize/session/upgrade', route => { bodies.push(route.request().postDataJSON()); return route.fulfill({ json: envelope(session()) }) })
  const page = await open(ctx)
  assert.deepEqual(bodies, [{ refresh_token: 'legacy-refresh-A' }])
  const state = await page.evaluate(() => consumer.store.getState())
  assert.equal(state.user.id, 'A')
  assert.equal(state.token, session().token)
  assert.deepEqual(state.permissions, ['software:read'])
  const left = await credentialsLeft(page)
  assert.deepEqual(left.storage, [])
  assert.equal(left.cookies, '')
  assert.ok(!left.persisted.includes(session().token), 'the access token is never persisted')
})

test('a spent or revoked legacy token signs out and still deletes it; a network failure keeps it for a retry', async t => {
  const ctx = await context(t, { 'auth-storage': legacy() })
  let calls = 0
  await ctx.route('**/api/authorize/session/upgrade', route => ++calls === 1 ? route.abort('failed') : route.fulfill({ status: 401, json: { message: 'Invalid session' } }))
  const page = await open(ctx)
  assert.equal(await page.evaluate(() => localStorage.getItem('auth-storage') !== null), true)
  assert.equal(await page.evaluate(() => consumer.store.getState().isAuthenticated), false)
  const second = await open(ctx)
  assert.equal(calls, 2)
  assert.deepEqual((await credentialsLeft(second)).storage, [])
  assert.equal(await second.evaluate(() => consumer.store.getState().isAuthenticated), false)
})

test('two tabs with the same legacy token spend it once and both continue from the cookie', async t => {
  const ctx = await context(t, { 'auth-storage': legacy() })
  let upgrades = 0, refreshes = 0
  await ctx.route('**/api/authorize/session/upgrade', async route => { upgrades++; await new Promise(done => setTimeout(done, 300)); return route.fulfill({ json: envelope(session()) }) })
  await ctx.route('**/api/authorize/refresh', route => { refreshes++; return route.fulfill({ json: envelope({ access_token: jwt('A', 'A-session', 2) }) }) })
  const [first, second] = await Promise.all([open(ctx, '/login', { boot: false }), open(ctx, '/login', { boot: false })])
  await Promise.all([first.evaluate(() => consumer.bootSession()), second.evaluate(() => consumer.bootSession())])
  assert.equal(upgrades, 1)
  assert.equal(refreshes, 1, 'the losing tab restores from the cookie the winner received')
  for (const page of [first, second]) assert.equal(await page.evaluate(() => consumer.store.getState().user?.id), 'A')
})

test('a reload restores the access token from the cookie; a rejected cookie signs out', async t => {
  const ctx = await context(t, { 'cc-account-session': summary() })
  let accepted = true
  await ctx.route('**/api/authorize/refresh', route => {
    assert.equal(route.request().method(), 'POST')
    return accepted ? route.fulfill({ json: envelope({ access_token: jwt('A', 'A-session', 2) }) }) : route.fulfill({ status: 401, json: { message: 'Invalid or expired session' } })
  })
  const page = await open(ctx)
  assert.equal(await page.evaluate(() => consumer.store.getState().token), jwt('A', 'A-session', 2))
  accepted = false
  await page.evaluate(() => consumer.store.setState({ token: null }))
  assert.equal(await page.evaluate(() => consumer.cookieSession.restore()), 'anonymous')
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem(consumer.persistKey)).state.isAuthenticated), false)
})

test('concurrent 401s share one cookie refresh and retry with the rotated token', async t => {
  const ctx = await context(t, { 'cc-account-session': summary() })
  let refreshes = 0
  await ctx.route('**/api/authorize/refresh', route => { refreshes++; return route.fulfill({ json: envelope({ access_token: jwt('A', 'A-session', refreshes + 1) }) }) })
  const page = await open(ctx)
  const current = await page.evaluate(() => consumer.store.getState().token)
  await page.route('**/api/probe', route => route.request().headers().authorization === `Bearer ${current}`
    ? route.fulfill({ status: 401, json: { message: 'expired' } }) : route.fulfill({ json: envelope({ ok: true }) }))
  const results = await page.evaluate(() => Promise.all([consumer.httpClient.get('/probe'), consumer.httpClient.get('/probe')]))
  assert.deepEqual(results, [{ ok: true }, { ok: true }])
  assert.equal(refreshes, 2, 'one restore and one rotation')
})

test('password sign-in uses the product route and keeps the destination; EMAIL_NOT_VERIFIED offers the verification mail', async t => {
  const ctx = await context(t)
  await ctx.route('**/api/authorize/oauth/providers', route => route.fulfill({ json: envelope({ providers: [] }) }))
  let attempts = 0, verifications = 0
  await ctx.route('**/api/authorize/password-login', route => {
    assert.deepEqual(route.request().postDataJSON(), { login: 'a@example.test', password: 'synthetic-password' })
    return ++attempts === 1 ? route.fulfill({ status: 401, json: { message: 'Invalid credentials' } })
      : attempts === 2 ? route.fulfill({ status: 403, json: { code: 'EMAIL_NOT_VERIFIED', message: 'Email not verified', details: { email: 'a@example.test' } } })
      : route.fulfill({ json: envelope(session()) })
  })
  await ctx.route('**/api/authorize/verification', route => { verifications++; assert.deepEqual(route.request().postDataJSON(), { email: 'a@example.test' }); return route.fulfill({ json: envelope({ accepted: true }) }) })
  const page = await open(ctx, '/login?redirect=%2Fpricing')
  await page.evaluate(() => consumer.mount('login'))
  await page.getByRole('button', { name: '使用密码登录' }).click()
  await page.getByLabel('邮箱', { exact: true }).fill('a@example.test')
  await page.getByLabel('密码', { exact: true }).fill('synthetic-password')
  await page.getByRole('button', { name: '登录账户' }).click()
  await page.getByRole('alert').filter({ hasText: '邮箱或密码不正确' }).waitFor()
  assert.equal(await page.getByRole('button', { name: '重新发送验证邮件' }).count(), 0)
  await page.getByRole('button', { name: '登录账户' }).click()
  await page.getByRole('alert').filter({ hasText: '邮箱尚未验证' }).waitFor()
  await page.getByRole('button', { name: '重新发送验证邮件' }).click()
  await page.waitForFunction(() => window.__redirect?.startsWith('/verify-email?'))
  assert.equal(verifications, 1)
  await page.evaluate(() => { window.__redirect = undefined })
  await page.getByRole('button', { name: '登录账户' }).click()
  await page.waitForFunction(() => window.__redirect === '/pricing')
  assert.equal(await page.evaluate(() => consumer.store.getState().user.id), 'A')
})

test('e-mail code sign-in sends a scoped code and opens the session', async t => {
  const ctx = await context(t)
  await ctx.route('**/api/authorize/oauth/providers', route => route.fulfill({ json: envelope({ providers: [] }) }))
  let sends = 0
  await ctx.route('**/api/authorize/login-code/send', route => { sends++; assert.deepEqual(route.request().postDataJSON(), { email: 'new@example.test' }); return route.fulfill({ json: envelope({ accepted: true }) }) })
  await ctx.route('**/api/authorize/login-code', route => { assert.deepEqual(route.request().postDataJSON(), { email: 'new@example.test', code: '123456' }); return route.fulfill({ json: envelope(session('N')) }) })
  const page = await open(ctx, '/login?redirect=%2Fdashboard')
  await page.evaluate(() => consumer.mount('login'))
  await page.getByLabel('邮箱', { exact: true }).fill('new@example.test')
  await page.getByRole('button', { name: '获取验证码' }).click()
  await page.getByRole('status').filter({ hasText: '验证码已发送' }).waitFor()
  assert.equal(await page.getByRole('button', { name: /s 后重发/ }).isDisabled(), true)
  await page.getByLabel('邮箱验证码').fill('123456')
  await page.getByRole('button', { name: '验证并继续' }).click()
  await page.waitForFunction(() => window.__redirect === '/dashboard')
  assert.equal(sends, 1)
  assert.equal(await page.evaluate(() => consumer.store.getState().user.id), 'N')
})

test('Google One Tap runs start → onetap → complete with the server nonce', async t => {
  const ctx = await context(t)
  await ctx.route('**/api/authorize/oauth/providers', route => route.fulfill({ json: envelope({ providers: [{ id: 'google', code: false, oneTapClientId: 'synthetic-client' }] }) }))
  await ctx.route('**/api/authorize/oauth/google/start', route => { assert.deepEqual(route.request().postDataJSON(), { mode: 'onetap' }); return route.fulfill({ json: envelope({ intent: 'intent-1', nonce: 'server-nonce', clientId: 'synthetic-client' }) }) })
  await ctx.route('**/api/authorize/oauth/google/onetap', route => { assert.deepEqual(route.request().postDataJSON(), { intent: 'intent-1', credential: 'signed-synthetic-proof' }); return route.fulfill({ json: envelope({ proof: 'proof-1', provider: 'google', purpose: 'login' }) }) })
  await ctx.route('**/api/authorize/oauth/google/complete', route => { assert.deepEqual(route.request().postDataJSON(), { proof: 'proof-1' }); return route.fulfill({ json: envelope({ ...session('G'), returnPath: '/prototype' }) }) })
  const page = await open(ctx)
  await page.evaluate(() => { window.google = { accounts: { id: { initialize(o) { window.googleOptions = o }, renderButton(el) { const b = document.createElement('button'); b.textContent = 'Synthetic Google consent'; b.onclick = () => window.googleOptions.callback({ credential: 'signed-synthetic-proof' }); el.append(b) } } } } })
  await page.evaluate(() => consumer.mount('login'))
  await page.getByRole('button', { name: 'Synthetic Google consent' }).click()
  await page.waitForFunction(() => consumer.store.getState().user?.id === 'G')
  assert.equal(await page.evaluate(() => window.googleOptions.nonce), 'server-nonce')
  assert.equal(await page.evaluate(() => window.__redirect), '/tools/prototype')
})

test('account page saves the profile, revokes a device, keeps the session on a wrong password and signs out after a change', async t => {
  const ctx = await context(t, { 'cc-account-session': summary() })
  await ctx.route('**/api/authorize/refresh', route => route.fulfill({ json: envelope({ access_token: jwt('A', 'A-session', 2) }) }))
  const calls = []
  await ctx.route('**/api/authorize/profile', route => { calls.push(['profile', route.request().postDataJSON()]); return route.fulfill({ json: envelope({ success: true }) }) })
  await ctx.route('**/api/authorize/sessions', route => route.fulfill({ json: envelope([{ id: 'A-session', current: true, lastActiveAt: '2026-11-10T01:00:00Z', expiresAt: '2026-12-10T01:00:00Z' }, { id: 'other', current: false, lastActiveAt: null, expiresAt: '2026-12-01T01:00:00Z' }]) }))
  await ctx.route('**/api/authorize/sessions/other', route => { assert.equal(route.request().method(), 'DELETE'); return route.fulfill({ json: envelope({ success: true }) }) })
  let passwordAttempts = 0
  await ctx.route('**/api/authorize/password', route => {
    calls.push(['password', route.request().postDataJSON()])
    return ++passwordAttempts === 1 ? route.fulfill({ status: 401, json: { message: 'Invalid current password' } }) : route.fulfill({ json: envelope({ success: true }) })
  })
  const page = await open(ctx, '/account')
  await page.evaluate(() => consumer.mount('account'))
  await page.getByLabel('显示名称').fill('合成新名称')
  await page.getByRole('button', { name: '保存资料' }).click()
  await page.getByText('资料已保存', { exact: true }).waitFor()
  assert.equal(await page.evaluate(() => consumer.store.getState().user.name), '合成新名称')
  await page.getByRole('button', { name: '退出此会话' }).click()
  await page.getByText('会话已退出', { exact: true }).waitFor()
  await page.getByLabel('当前密码', { exact: true }).fill('wrong-password')
  await page.getByLabel('新密码', { exact: true }).fill('new-test-password')
  await page.getByLabel('确认新密码', { exact: true }).fill('new-test-password')
  await page.getByRole('button', { name: '更新密码' }).click()
  await page.getByRole('alert').filter({ hasText: '密码修改失败' }).waitFor()
  assert.equal(await page.evaluate(() => consumer.store.getState().isAuthenticated), true, 'a wrong current password keeps the session')
  await page.getByLabel('当前密码', { exact: true }).fill('old-test-password')
  await page.getByRole('button', { name: '更新密码' }).click()
  await page.waitForFunction(() => window.__redirect?.startsWith('/login'))
  assert.equal(await page.evaluate(() => consumer.store.getState().token), null)
  assert.deepEqual(calls.at(-1), ['password', { currentPassword: 'old-test-password', password: 'new-test-password' }])
  assert.deepEqual(calls[0], ['profile', { name: '合成新名称' }])
})

test('forgot password mails a code through the host and resets with it', async t => {
  const ctx = await context(t)
  await ctx.route('**/api/authorize/forgot-password', route => { assert.deepEqual(route.request().postDataJSON(), { email: 'a@example.test' }); return route.fulfill({ json: envelope({ accepted: true }) }) })
  await ctx.route('**/api/authorize/reset-password', route => { assert.deepEqual(route.request().postDataJSON(), { email: 'a@example.test', code: '654321', password: 'new-test-password' }); return route.fulfill({ json: envelope({ success: true }) }) })
  const page = await open(ctx, '/forgot-password')
  await page.evaluate(() => consumer.mount('forgot'))
  await page.getByLabel('注册邮箱').fill('a@example.test')
  await page.getByRole('button', { name: '发送验证码' }).click()
  await page.getByRole('status').filter({ hasText: '验证码已发送' }).waitFor()
  await page.getByLabel('验证码').fill('654321')
  await page.getByLabel('新密码', { exact: true }).fill('new-test-password')
  await page.getByLabel('确认新密码').fill('new-test-password')
  await page.getByRole('button', { name: '重置密码' }).click()
  await page.getByText('密码已重置，请重新登录。').waitFor()
})

test('sign-out in one tab signs out the other; a sign-in in another tab is followed through the cookie', async t => {
  const ctx = await context(t, { 'cc-account-session': summary() })
  await ctx.route('**/api/authorize/refresh', route => route.fulfill({ json: envelope({ access_token: jwt('A', 'A-session', 3) }) }))
  const first = await open(ctx, '/dashboard')
  const second = await open(ctx, '/dashboard')
  await first.evaluate(() => consumer.mount(null))
  await second.evaluate(() => consumer.mount(null))
  await first.evaluate(() => consumer.store.getState().logout())
  await second.waitForFunction(() => !consumer.store.getState().isAuthenticated)
  // Sign in again in the second tab; the first follows from the shared cookie.
  await second.evaluate(async token => { await consumer.cookieSession.adoptToken(token) }, jwt('A', 'A-session', 4))
  await first.waitForFunction(() => consumer.store.getState().user?.id === 'A' && Boolean(consumer.store.getState().token))
})

test('/prototype/* sends a visitor without a session to login once restore has settled', async t => {
  const ctx = await context(t)
  const page = await open(ctx, '/prototype/p-1?document=d-1', { boot: false })
  await page.evaluate(() => consumer.mount(null))
  await page.waitForURL(url => url.pathname === '/login')
  assert.equal(new URL(page.url()).searchParams.get('redirect'), '/prototype/p-1?document=d-1')
})

test('a shared refresh cookie for account B never replays account A requests as B', async t => {
  const ctx = await context(t, { 'cc-account-session': summary('A') })
  let calls = 0
  await ctx.route('**/api/authorize/refresh', route => route.fulfill({ json: envelope({ access_token: jwt(++calls === 1 ? 'A' : 'B', calls === 1 ? 'A-session' : 'B-session', 2) }) }))
  const page = await open(ctx, '/login')
  const requestTokens = []
  await page.route('**/api/identity-probe', route => {
    requestTokens.push(route.request().headers().authorization)
    return route.fulfill({ status: 401, json: { message: 'expired' } })
  })
  const result = await page.evaluate(() => consumer.httpClient.post('/identity-probe', { originalAccount: 'A' }).then(() => 'succeeded', e => e.status))
  assert.equal(result, 401)
  assert.equal(calls, 2)
  assert.deepEqual(requestTokens, [`Bearer ${jwt('A', 'A-session', 2)}`])
  const state = await page.evaluate(() => consumer.store.getState())
  assert.equal(state.isAuthenticated, false)
  assert.equal(state.token, null)
  assert.equal(state.user, null)
})

test('a late mutation from account A is cancelled when this tab explicitly signs in as B', async t => {
  const ctx = await context(t, { 'cc-account-session': summary('A') })
  let refreshes = 0
  await ctx.route('**/api/authorize/refresh', route => { refreshes++; return route.fulfill({ json: envelope({ access_token: jwt('A', 'A-session', 2) }) }) })
  const page = await open(ctx, '/login')
  let release, started
  const ready = new Promise(resolve => { started = resolve })
  const gate = new Promise(resolve => { release = resolve })
  const tokens = []
  await page.route('**/api/late-mutation', async route => {
    tokens.push(route.request().headers().authorization)
    started()
    await gate
    await route.fulfill({ status: 401, json: { message: 'expired' } }).catch(() => {})
  })
  await page.evaluate(() => { window.pendingMutation = consumer.httpClient.post('/late-mutation', { originalAccount: 'A' }).then(() => 'succeeded', e => e.code) })
  await ready
  await page.evaluate(token => consumer.cookieSession.adoptToken(token), jwt('B', 'B-session', 1))
  release()
  assert.equal(await page.evaluate(() => window.pendingMutation), 'ERR_CANCELED')
  assert.equal(refreshes, 1)
  assert.equal(tokens.length, 1)
  const state = await page.evaluate(() => consumer.store.getState())
  assert.equal(state.user.id, 'B')
  assert.equal(state.token, jwt('B', 'B-session', 1))
})
