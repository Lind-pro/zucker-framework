// @vitest-environment node
// Synthetic joint regression against ccopyright migrate/framework dac278e.
// Uses the actual consumer controller, options factory and CopyrightDatabase. The generated Prisma
// client is replaced with delegates that execute PostgreSQL in PGlite; no consumer services/providers run.
import { PGlite } from '@electric-sql/pglite';
import { JwtService } from '@nestjs/jwt';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { DimensionUserService, type PermissionService } from '@zucker-framework/auth';
import { AccountService, resolveAccountsOptions, AccountSessionAdminHooks, DEFAULT_ACCOUNT_POLICY } from '@zucker-framework/back-office/accounts';
import { PgTestAdapter, type PgQueryable } from '/Users/lind/Documents/projects/zucker-framework/packages/back-office/src/subscriptions/testing/pg-test-adapter';
import { CopyrightDatabase, CopyrightTransaction } from '/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/infrastructure/database/framework-database';
import { CopyrightUsersController } from '/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/modules/back-office/copyright-users.controller';
import { copyrightAccountOptions } from '/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/modules/accounts/accounts.module';

vi.mock('/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/infrastructure/cache/cache.module', () => ({ CacheModule: class {} }));
vi.mock('/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/modules/accounts/account-policy', () => ({
  CopyrightAccountPolicy: class {}, CopyrightCredentialPolicy: class {}, CopyrightSignupHooks: class {}, CopyrightVerificationAttempts: class {},
}));
vi.mock('/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/modules/accounts/google-sign-in', () => ({ CopyrightGoogleClient: class {}, CopyrightOAuthSettings: class {} }));
vi.mock('/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/modules/accounts/legacy-session', () => ({ LegacyAccessTokenVerifier: class {}, LegacySessionUpgradeController: class {} }));
vi.mock('/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/modules/accounts/optional-account.guard', () => ({ OptionalAccountGuard: class {} }));
vi.mock('/tmp/zucker-ccopyright-joint-dac278e/apps/server/src/modules/accounts/product-sign-in.controller', () => ({ LOGIN_CODE_METHOD: 'email-code', ProductSignInController: class {} }));

const PASSWORD = 'Synthetic!Passw0rd#CC';
const JWT_SECRET = 'synthetic-jwt-secret-for-cc-joint-0123456789';
const SCHEMA = `
CREATE TABLE users (id text PRIMARY KEY DEFAULT gen_random_uuid()::text, username text NOT NULL UNIQUE, password text, name text NOT NULL, email text UNIQUE,
  "emailVerified" boolean NOT NULL DEFAULT false, "typeId" text NOT NULL, status boolean NOT NULL DEFAULT true, locale text, "creatorId" text,
  "credentialVersion" int NOT NULL DEFAULT 0, "createTime" timestamptz NOT NULL DEFAULT now(), "createdAt" timestamptz NOT NULL DEFAULT now());
CREATE TABLE auth_sessions (id text PRIMARY KEY, "userId" text NOT NULL, "refreshJti" text NOT NULL UNIQUE, "expiresAt" timestamptz NOT NULL,
  "revokedAt" timestamptz, "revokedReason" text, "lastActiveAt" timestamptz NOT NULL DEFAULT now(), "credentialVersion" int NOT NULL DEFAULT 0,
  "authMethod" text, "oauthBindingId" text, "createdAt" timestamptz NOT NULL DEFAULT now());
`;
function client(pg: Pick<PGlite, 'query'>, transaction?: PGlite['transaction']) {
  const q: PgQueryable = { async query(sql, values) {
    const result = await pg.query<Record<string, unknown>>(sql, values);
    return { rows: result.rows, rowCount: result.affectedRows ?? null };
  } };
  const adapter = new PgTestAdapter(q, true);
  return { user: adapter.model('users'), authSession: adapter.model('auth_sessions'),
    $queryRawUnsafe: async (sql: string, ...values: unknown[]) => (await pg.query(sql, values)).rows,
    $transaction: (work: (tx: unknown) => Promise<unknown>) => {
      if (!transaction) throw new Error('nested root transaction is forbidden');
      return transaction(tx => work(client(tx)));
    },
  };
}
const actor = { user: { id: 'synthetic-cc-admin' } };
const permissions = { findUserPermissions: async (id: string) => id === actor.user.id ? ['superadmin'] : [], hasPermission: async () => true } as unknown as PermissionService;

describe('ccopyright dac278e with Framework account fixes', () => {
  let pg: PGlite, db: CopyrightDatabase;
  beforeAll(async () => {
    pg = await PGlite.create(); await pg.exec(SCHEMA);
    db = new CopyrightDatabase(client(pg, pg.transaction.bind(pg)) as never);
  }, 30_000);
  afterAll(async () => { await pg?.close(); });
  function host(emailLogin = false) {
    const productOptions = copyrightAccountOptions();
    const options = resolveAccountsOptions({ ...productOptions, ...(emailLogin ? { login: { identifier: 'email' as const } } : {}) });
    const jwt = new JwtService({ secret: JWT_SECRET });
    const accounts = new AccountService(db, jwt, { send: async () => { throw new Error('mail is outside test scope'); } },
      options, { policy: async () => ({ ...DEFAULT_ACCOUNT_POLICY, requireEmailVerification: false }) });
    const hooks = new AccountSessionAdminHooks(db, options);
    return { accounts, jwt, options, hooks,
      controller: new CopyrightUsersController(accounts.users(), permissions, new DimensionUserService(db), db, {}, hooks),
    };
  }
  it('R02 rolls back actual consumer emailVerified policy plus credential/session writes and retries same body', async () => {
    const f = host();
    const user = await f.controller.create({ username: ' cc-atomic ', email: ' Before@Example.Invalid ', password: PASSWORD, emailVerified: true }, actor);
    expect(user).toMatchObject({ username: 'cc-atomic', name: 'cc-atomic', typeId: 'user', email: 'before@example.invalid', emailVerified: true });
    const signedIn = await f.accounts.login({ username: 'cc-atomic', password: PASSWORD }) as { accessToken: string };
    const { sid } = await f.jwt.verifyAsync(signedIn.accessToken, { audience: f.options.tokens.accessAudience });
    let fail = true;
    const original = f.hooks.sensitiveFieldsChanging.bind(f.hooks);
    const changing = vi.spyOn(f.hooks, 'sensitiveFieldsChanging').mockImplementation(async (change, tx) => {
      expect(tx).toBeInstanceOf(CopyrightTransaction);
      await original(change, tx);
      if (fail) throw new Error('synthetic post-write transaction failure');
    });
    const input = { email: ' After@Example.Invalid ' };
    await expect(f.controller.update(user.id, input, actor)).rejects.toThrow('synthetic post-write transaction failure');
    expect(await f.accounts.currentUser(user.id, sid)).toMatchObject({ email: 'before@example.invalid', emailVerified: true, credentialVersion: 0 });
    fail = false;
    await expect(f.controller.update(user.id, input, actor)).resolves.toMatchObject({ email: 'after@example.invalid', emailVerified: false });
    expect(changing).toHaveBeenCalledTimes(2);
    expect(await db.model('users').findUnique({ where: { id: user.id } })).toMatchObject({ credentialVersion: 1 });
    expect(await db.model('accountSessions').findUnique({ where: { id: sid } })).toMatchObject({ revokedReason: 'admin-credential-change' });
    await expect(f.accounts.currentUser(user.id, sid)).rejects.toMatchObject({ status: 401 });
  });
  it('R15 keeps actual consumer defaults and supports opt-in email login for normalized and legacy data', async () => {
    const actual = host();
    expect(actual.options.login.identifier).toBe('username');
    const user = await actual.controller.create({ username: 'cc-email', email: ' Mixed.Case@Example.Invalid ', password: PASSWORD, emailVerified: true }, actor);
    expect(user.email).toBe('mixed.case@example.invalid');
    const emailHost = host(true); // Explicit synthetic option: current ccopyright defaults to username login.
    await expect(emailHost.accounts.login({ email: 'Mixed.Case@Example.Invalid', password: PASSWORD })).resolves.toMatchObject({ userId: user.id });
    await db.model('users').update({ where: { id: user.id }, data: { email: 'Legacy.Mixed@Example.Invalid' } });
    await expect(emailHost.accounts.login({ email: 'legacy.mixed@example.invalid', password: PASSWORD })).resolves.toMatchObject({ userId: user.id });
    await actual.controller.create({ username: 'cc-collision', email: 'legacy.mixed@example.invalid', password: PASSWORD, emailVerified: true }, actor);
    await expect(emailHost.accounts.login({ email: 'Legacy.Mixed@Example.Invalid', password: PASSWORD })).rejects.toMatchObject({ status: 401 });
  });
});
