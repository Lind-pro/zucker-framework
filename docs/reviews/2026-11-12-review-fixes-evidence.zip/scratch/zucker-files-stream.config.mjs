import { createRequire } from 'node:module';
import base from '/Users/lind/Documents/projects/zucker-framework/vitest.config.ts';
const require = createRequire('/Users/lind/Documents/projects/zucker-framework/templates/server/package.json');
const swc = require('unplugin-swc').default;
export default { ...base,
  plugins: [swc.vite({module:{type:'es6'},jsc:{parser:{syntax:'typescript',decorators:true},transform:{legacyDecorator:true,decoratorMetadata:true},target:'es2022'}})],
  resolve: {...base.resolve, alias:[...base.resolve.alias, ...['@nestjs/common','@nestjs/core','@nestjs/jwt','@nestjs/event-emitter','pg'].map(name=>({find:new RegExp(`^${name}$`),replacement:require.resolve(name)}))]},
  test:{...base.test,environment:'node',include:['templates/server/test/files-stream-lifecycle.unit.e2e-spec.ts']}
};
