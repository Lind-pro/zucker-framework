import { createRequire } from 'node:module';
import { defineConfig } from 'vitest/config';
import base from './vitest.config';
const serverRequire = createRequire(new URL('./templates/server/package.json', import.meta.url));
const existing = ['@nestjs/common', '@nestjs/core', '@nestjs/jwt', '@nestjs/event-emitter', '@nestjs/testing', '@nestjs/platform-express', 'pg', 'supertest', 'rxjs', 'reflect-metadata'];
export default defineConfig({
  ...base,
  resolve: { ...base.resolve, alias: [
    ...(base.resolve!.alias as any[]),
    ...existing.map(name => ({ find: new RegExp(`^${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`), replacement: serverRequire.resolve(name) })),
  ] },
  test: { ...base.test, maxWorkers: 4 },
});
