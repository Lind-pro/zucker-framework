import { describe, expect, it } from 'vitest';
import { PassThrough } from 'node:stream';
import { FilesService } from '../../../templates/server/src/files/files.service';

describe('review: generated file stream lifecycle', () => {
  it('closes the storage read when the returned download stream is destroyed', async () => {
    const upstream = new PassThrough();
    const asset = { id: 'synthetic-file', state: 'ready', size: 20, objectKey: 'synthetic', sha256: 'unused' };
    const service = Object.create(FilesService.prototype) as FilesService;
    Object.assign(service, {
      assets: { inspect: async () => asset },
      options: { maxObjectBytes: 10 },
      manager: { download: async () => ({ stream: upstream, size: 20 }) },
    });
    try {
      const opened = await service.open('synthetic-user', 'synthetic-file');
      if (!('stream' in opened)) throw new Error('Expected streaming read');
      opened.stream.destroy();
      await new Promise(resolve => setImmediate(resolve));
      expect(upstream.destroyed).toBe(true);
    } finally { upstream.destroy(); }
  });
});
