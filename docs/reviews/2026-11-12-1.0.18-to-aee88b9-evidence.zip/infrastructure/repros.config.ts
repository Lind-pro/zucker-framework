import config from './vitest.config';
export default { ...config, test: { ...config.test, include: ['./.review-infrastructure.spec.ts'] } };
