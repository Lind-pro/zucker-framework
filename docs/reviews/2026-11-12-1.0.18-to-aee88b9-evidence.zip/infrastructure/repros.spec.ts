import { afterEach, expect, it, vi } from 'vitest';
import { EventEmitter } from 'node:events';
import { RedisCacheService } from './packages/cache/src/redis-cache.service';
import { CrudService } from './packages/crud/src/base.service';
import { DynamicQueryService, DynamicQueryParamService } from './packages/crud/src/dynamic-query.service';
import { ALL_OPERATORS, FilterOperatorFactory } from './packages/crud/src/operators';

afterEach(() => { vi.useRealTimers(); vi.restoreAllMocks(); });

it('review repro: expired pending Redis SET must not delete a subsequent successful SET', async () => {
  vi.useFakeTimers();
  class FakeRedis extends EventEmitter {
    store = new Map<string, string>();
    async connect() { this.emit('ready'); }
    disconnect() {}
    async get(key: string) { return this.store.get(key) ?? null; }
    async set(key: string, value: string) { this.store.set(key, value); return 'OK'; }
    async del(...keys: string[]) { keys.forEach(key => this.store.delete(key)); return keys.length; }
  }
  const client = new FakeRedis();
  const service = new RedisCacheService({ url: 'redis://synthetic.invalid', createClient: () => client as never });
  await service.onModuleInit();
  client.emit('close');
  await service.set('profile', 'expired outage write', 1);
  await vi.advanceTimersByTimeAsync(2000);
  client.emit('ready');
  await service.set('profile', 'fresh after recovery', 60);
  expect(client.store.get('profile')).toBe('"fresh after recovery"');
  const observed = await service.get('profile');
  service.onModuleDestroy();
  expect(observed).toBe('fresh after recovery');
});

it('review repro: dynamic reads must share the propagated CRUD transaction', async () => {
  const rootRows: any[] = [];
  const txRows: any[] = [];
  const operations = (rows: any[]) => ({
    create: async ({ data }: any) => { const row = { id: 'a', ...data }; rows.push(row); return row; },
    findMany: async () => [...rows],
    findUnique: async ({ where }: any) => rows.find(r => r.id === where.id) ?? null,
    count: async () => rows.length,
  });
  const rootOps = operations(rootRows);
  const txOps = operations(txRows);
  const tx = { model: () => txOps };
  const db = { model: () => rootOps, $transaction: async (fn: any) => fn(tx) };
  const dynamic = new DynamicQueryService(db as never, new DynamicQueryParamService(new FilterOperatorFactory(ALL_OPERATORS.map(Op => new Op()))));
  class Rows extends CrudService<any> {}
  const service = new Rows(db as never, dynamic, 'rows');
  await service.transaction(async () => {
    await service.create({ name: 'uncommitted' });
    expect(await service.findOne('a')).toEqual({ id: 'a', name: 'uncommitted' });
    expect((await service.findAll({})).data).toEqual([{ id: 'a', name: 'uncommitted' }]);
  });
});
