import { expect, it } from 'vitest';
import { mkdtempSync, writeFileSync, rmSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { PersistenceBuffer } from './packages/buffer/src/persistence-buffer';

it('review repro: survivor must reclaim a peer claim after its first flush', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'zucker-review-buffer-'));
  const seen: string[] = [];
  const buf = new PersistenceBuffer<string>({ fileQueueDir: dir, bufferSize: 100 });
  buf.onFlush(async rows => { seen.push(...rows); });
  try {
    await buf.flush();
    // A peer crashes after this instance has already started and flushed once.
    writeFileSync(join(dir, 'buffer-1-1-x.json.2147483646-deadbeef.processing'), JSON.stringify(['orphan']));
    await buf.flush();
    await buf.flush();
    expect({ seen, files: readdirSync(dir) }).toEqual({ seen: ['orphan'], files: [] });
  } finally {
    await buf.stop();
    rmSync(dir, { recursive: true, force: true });
  }
});
