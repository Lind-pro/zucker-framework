import { createRequire } from 'node:module';
import base from '/Users/lind/Documents/projects/zucker-framework/vitest.config.ts';
const require = createRequire('/Users/lind/Documents/projects/zucker-framework/templates/server/package.json');
export default { ...base, resolve: { ...base.resolve, alias: [
  ...['@nestjs/common','@nestjs/core','@nestjs/jwt','@nestjs/event-emitter'].map(name => ({find:name,replacement:require.resolve(name)})),
  ...base.resolve.alias,
] } };
