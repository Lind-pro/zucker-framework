// @vitest-environment node
import { expect, it } from 'vitest';
import { createRequire } from 'node:module';
import { SubscriptionAssignmentService } from '@zucker-framework/payment';
import { createSqlBillingLink } from './billing-link';
const require = createRequire(new URL('../../../../credit/package.json', import.meta.url));
const { PGlite } = require('@electric-sql/pglite');
it('review repro: pending checkout must not mask a provider subscription', async () => {
  const pg = new PGlite();
  try {
    await pg.exec(`CREATE TABLE billing_orders (id text, "ownerId" text, offer jsonb, state text, "createdAt" timestamptz);
      CREATE TABLE billing_subscriptions (id text, "ownerId" text, offer jsonb, status text, "currentPeriodEnd" timestamptz, "createdAt" timestamptz);
      INSERT INTO billing_orders VALUES ('unpaid-checkout','u','{"fulfillmentData":{"plan":{"planId":"p"}}}','pending',now());
      INSERT INTO billing_subscriptions VALUES ('active-paid-subscription','u','{"fulfillmentData":{"plan":{"planId":"p"}}}','active',now()+interval '1 month',now());`);
    const tx = { query: (sql: string, params: unknown[]) => pg.query(sql, params) };
    const link = createSqlBillingLink();
    const blocking = await link.pendingPlanPayment(tx as never, 'u', new Date());
    console.log('synthetic SQL blocker', blocking);
    const service = new SubscriptionAssignmentService({
      transaction: async (_id: string, work: any) => work(tx),
      pendingPayment: async () => blocking,
      find: async () => ({ planId: 'existing-plan', billingCycle: 'MONTHLY', endDate: new Date(Date.now()+86400000), source: 'payment' }),
    } as never, { activeTerm: () => true });
    await expect(service.admitPurchase('u', {planId:'p', billingCycle:'MONTHLY'})).rejects.toMatchObject({reason:'pending_payment'});
  } finally { await pg.close(); }
});
