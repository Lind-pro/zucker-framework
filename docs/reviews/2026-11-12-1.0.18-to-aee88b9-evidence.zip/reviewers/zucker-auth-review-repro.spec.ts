// @vitest-environment node
import { describe, expect, it, vi } from 'vitest';
import { DimensionUserService } from '@zucker-framework/auth';
import { UsersController } from '../../../admin/src/users/users.controller';
import { AccountSessionAdminHooks } from './admin-user-hooks';
import { createFixture, PASSWORD } from './testing/account-fixture';

const permissions = { findUserPermissions: async (id: string) => id === 'review-admin' ? ['superadmin'] : [], hasPermission: async () => true };
function admin(f: ReturnType<typeof createFixture>, hooks?: any) {
  return new UsersController(f.accounts.users(), permissions as any, new DimensionUserService(f.db), f.db, {}, hooks);
}
describe('review reproduction: account/admin integration invariants', () => {
  it('retries session revocation after a failed email-change hook', async () => {
    const f = createFixture();
    const user = await f.createUser('review-user');
    const session = await f.accounts.login({ username: user.username, password: PASSWORD }) as { accessToken: string };
    const claims = await f.jwt.verifyAsync(session.accessToken, { audience: f.options.tokens.accessAudience });
    const real = new AccountSessionAdminHooks(f.db, f.options);
    const hooks = { sensitiveFieldsChanged: vi.fn().mockRejectedValueOnce(new Error('transient session-store failure')).mockImplementation(real.sensitiveFieldsChanged.bind(real)) };
    const controller = admin(f, hooks);
    const body = { email: 'updated@example.invalid' };
    await expect(controller.update(user.id, body, { user: { id: 'review-admin' } })).rejects.toThrow('transient');
    await controller.update(user.id, body, { user: { id: 'review-admin' } });
    expect((await f.accounts.currentUser(user.id, claims.sid)).email).toBe('updated@example.invalid');
    expect(hooks.sensitiveFieldsChanged).toHaveBeenCalledTimes(2);
  });
  it('lets an admin-created mixed-case email account sign in in email mode', async () => {
    const f = createFixture({ login: { identifier: 'email' } });
    const controller = admin(f);
    await controller.create({ username: 'review-email', email: 'Alice@Example.invalid', name: 'Alice', password: PASSWORD, emailVerified: true, typeId: 'member' }, { user: { id: 'review-admin' } });
    await expect(f.accounts.login({ email: 'Alice@Example.invalid', password: PASSWORD })).resolves.toMatchObject({ twoFactorRequired: false });
  });
});

import { generateTotpCode } from '@zucker-framework/auth';

describe('review reproduction: two-factor invariants', () => {
  it('does not spend a TOTP when its database claim fails before any write', async () => {
    const f = createFixture();
    const user = await f.createUser('review-factor');
    const { secret } = await f.twoFactor!.enrol(user);
    const code = () => generateTotpCode({ secret, time: f.clock.now.getTime() });
    await f.twoFactor!.confirm(user.id, 'test-session', code());
    f.clock.advance(31);
    const original = f.db.model.bind(f.db);
    const spy = vi.spyOn(f.db, 'model').mockImplementation((name) => {
      const model = original(name);
      if (name !== 'accountTwoFactor') return model;
      return new Proxy(model, { get(target, key) {
        if (key === 'updateMany') return async () => { throw new Error('transient database failure before write'); };
        return Reflect.get(target, key);
      } });
    });
    await expect(f.twoFactor!.verify(f.db, user.id, { code: code() })).rejects.toThrow('transient database failure');
    spy.mockRestore();
    await expect(f.twoFactor!.verify(f.db, user.id, { code: code() })).resolves.toBe(true);
  });
});

import { TokenService } from '@zucker-framework/auth';
it('does not resurrect an older access token when revocations complete out of order', async () => {
  const map = new Map<string, unknown>();
  let release!: () => void, started!: () => void;
  const wait = new Promise<void>(r => { release = r; });
  const ready = new Promise<void>(r => { started = r; });
  let delayed = false;
  const cache = {
    get: async (key: string) => map.get(key), has: async (key: string) => map.has(key), del: async (key: string) => { map.delete(key); },
    set: async (key: string, value: unknown) => {
      if (key === 'token:revoked-after:victim' && !delayed) { delayed = true; started(); await wait; }
      map.set(key, value);
    },
  };
  const a = new TokenService(cache as any), b = new TokenService(cache as any);
  const now = vi.spyOn(Date, 'now').mockReturnValue(1000);
  try {
    const first = a.revokeUserTokens('victim');
    await ready;
    now.mockReturnValue(2000);
    const c = new TokenService(cache as any);
    await c.signIn('victim', 'existing-token');
    now.mockReturnValue(3000);
    await b.revokeUserTokens('victim');
    const tokenClaims = { sub: 'victim', iat: 2, sessionTracked: true };
    expect(await b.checkAccessToken('existing-token', tokenClaims)).toBe('user_revoked');
    release(); await first;
    expect(await b.checkAccessToken('existing-token', tokenClaims)).toBe('user_revoked');
  } finally { release(); now.mockRestore(); }
});
