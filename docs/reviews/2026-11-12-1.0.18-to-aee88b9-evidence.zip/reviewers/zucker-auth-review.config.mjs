import base from '/Users/lind/Documents/projects/zucker-framework/vitest.config.ts';
import {createRequire} from 'node:module';
const req = createRequire('/Users/lind/Documents/projects/zucker-framework/templates/server/package.json');
const aliases = ['@nestjs/common','@nestjs/core','@nestjs/jwt','@nestjs/event-emitter'].map(name => ({find: new RegExp('^'+name+'$'), replacement:req.resolve(name)}));
export default { ...base, resolve: { ...base.resolve, alias: [...base.resolve.alias, ...aliases] } };
