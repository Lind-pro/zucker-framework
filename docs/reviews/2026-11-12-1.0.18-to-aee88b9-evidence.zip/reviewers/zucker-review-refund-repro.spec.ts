import { describe, expect, it } from 'vitest';
import {
  SubscriptionAssignmentError, SubscriptionAssignmentService,
  type SubscriptionPaymentEvidence, type UserSubscriptionRecord, type UserSubscriptionStore,
} from '../index';

/** Minimal in-memory store: one term per user, a payment ledger by reference. */
function fixture(start = '2026-06-01T00:00:00Z') {
  const clock = { now: new Date(start) };
  const rows = new Map<string, UserSubscriptionRecord>();
  const evidence = new Map<string, SubscriptionPaymentEvidence>();
  const store: UserSubscriptionStore<'tx'> = {
    async transaction(_userId, work) { return work('tx'); },
    async userAssignable() { return true; },
    async find(_tx, id) { return rows.get(id) ?? null; },
    async findPlanBySlug(_tx, slug) { return { id: `p-${slug}`, slug, status: true }; },
    async findPlanById(_tx, id) { return { id, slug: id.replace(/^p-/, ''), status: true }; },
    async pendingPayment() { return null; },
    async recordPaymentEvidence(_tx, item) { if (evidence.has(item.reference)) return false; evidence.set(item.reference, item); return true; },
    async findPaymentEvidence(_tx, reference) { return evidence.get(reference) ?? null; },
    async save(_tx, userId, data) {
      const prior = rows.get(userId);
      const row = { ...data, id: prior?.id ?? `sub-${userId}`, userId, createdAt: prior?.createdAt ?? clock.now, updatedAt: clock.now };
      rows.set(userId, row); return row;
    },
  };
  const service = new SubscriptionAssignmentService(store, {
    now: () => clock.now,
    activeTerm: (term, at) => (term.status === 'ACTIVE' || term.status === 'CANCELED') && !!term.startDate && term.startDate <= at
      && (term.endDate ? term.endDate > at : term.billingCycle === 'LIFETIME'),
  });
  const D = (iso: string) => new Date(iso);
  return { service, clock, rows, evidence, D };
}

it('review repro: refunding both stacked payments must revoke all paid entitlement', async () => {
  const f = fixture();
  for (const reference of ['order:a', 'order:b']) await f.service.recordPayment({ userId: 'u', planId: 'p-pro', billingCycle: 'ONE_TIME', reference,
    periodStart: f.D('2026-06-01T00:00:00Z'), periodEnd: f.D('2026-07-01T00:00:00Z') });
  expect(f.rows.get('u')!.endDate).toEqual(f.D('2026-07-31T00:00:00Z'));
  const latest = await f.service.revokePayment({ userId: 'u', reference: 'order:b' });
  expect(latest.outcome).toBe('shortened');
  const earlier = await f.service.revokePayment({ userId: 'u', reference: 'order:a' });
  console.log('synthetic refund observations', { latest:latest.outcome, reference:latest.subscription?.paymentReference, earlier:earlier.outcome, status:earlier.subscription?.status, end:earlier.subscription?.endDate });
  expect(earlier.subscription?.status).toBe('EXPIRED');
});
