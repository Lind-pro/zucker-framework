// @vitest-environment node
import { readFileSync } from 'node:fs';
import { PGlite } from '@electric-sql/pglite';
import { DalleProvider } from '../../ai/src/providers/dalle.provider';
import { FAKE_PNG_BASE64, FakeMediaProvider } from '../../ai/src/testing/fake-media-provider';
import { AITaskService } from '../../ai-tasks/src/ai-task.service';
import { AI_TASKS_POSTGRESQL_SCHEMA } from '../../ai-tasks/src/schema';
import { DurableTaskRetryScheduledError, DurableWorkerRuntime } from './durable-worker-runtime';
import { PostgresTaskRepository } from './postgres-task-repository';
import { ExponentialTaskRetryPolicy } from './retry-policy';
import { postgresTaskTestSchemaSql } from './postgres-test-schema';

it('reproduces duplicate paid submission after a transient completion transaction failure', async () => {
  const db = await PGlite.create();
  try {
    await db.exec(postgresTaskTestSchemaSql);
    await db.exec(AI_TASKS_POSTGRESQL_SCHEMA);
    const fixture = readFileSync(new URL('../../ai-tasks/src/ai-task.integration.spec.ts', import.meta.url), 'utf8');
    await db.exec(fixture.match(/const WALLET_SQL = `([\s\S]*?)`;/)![1]!);
    let failOutputInsert = true;
    const adapt = (connection: any) => ({ query: async (sql: string, values?: readonly unknown[]) => {
      if (sql.includes('INSERT INTO ai_task_outputs') && failOutputInsert) {
        failOutputInsert = false;
        throw new Error('synthetic transient database write failure');
      }
      return connection.query(sql, values ? [...values] : []);
    } });
    const provider = new FakeMediaProvider({ defaultStep: { mode: 'sync' } });
    const tasks = new AITaskService({
      transactions: { runInTransaction: work => db.transaction(tx => work(adapt(tx))) },
      holds: { place: async () => {}, confirm: async () => {}, release: async () => {} },
      costs: { resolve: () => 0 },
      outputs: { put: async () => ({ storageKey: 'stored/result.png' }) },
      providers: { resolve: () => ({ provider, config: {} }) },
    });
    const { task } = await tasks.submitAndWake({ ownerId: 'review-user', kind: 'image', providerId: 'fake-media', model: 'fake-image', input: { prompt: 'test' }, idempotencyKey: 'review-key-0001' });
    const runtime = new DurableWorkerRuntime({
      repository: new PostgresTaskRepository(adapt(db)), resolveHandler: () => tasks.handler,
      retryPolicy: new ExponentialTaskRetryPolicy({ baseDelayMs: 0, maxDelayMs: 0 }),
      classifyError: () => ({ code: 'INTERNAL', category: 'INTERNAL', summary: 'transient', retryable: true }),
      workerId: 'review-worker',
    });
    await expect(runtime.run(task.id)).rejects.toBeInstanceOf(DurableTaskRetryScheduledError);
    expect(provider.calls.filter(call => call.method === 'generate')).toHaveLength(1);
    await expect(runtime.run(task.id)).resolves.toMatchObject({ status: 'COMPLETED' });
    expect(provider.calls.filter(call => call.method === 'generate')).toHaveLength(2);
  } finally { await db.close(); }
});

it.each(['dall-e-3', 'dall-e-2'])('reproduces count=4 delivering one result with %s', async modelId => {
  const provider = new DalleProvider();
  let submitted: any;
  (provider as any).createClient = async () => ({ images: { generate: async (params: any) => {
    submitted = params;
    return { data: Array.from({ length: params.n }, (_, index) => ({ b64_json: FAKE_PNG_BASE64, revised_prompt: `output-${index}` })) };
  } } });
  const result = await provider.generate('test', { apiKey: 'synthetic', modelId, count: 4 });
  expect(submitted.n).toBe(modelId === 'dall-e-3' ? 1 : 4);
  expect(result.revisedPrompt).toBe('output-0');
  expect((result as any).outputs).toBeUndefined();
});

it('reproduces a stalled output fetch surviving the configured task deadline', async () => {
  const db = await PGlite.create();
  try {
    await db.exec(postgresTaskTestSchemaSql);
    await db.exec(AI_TASKS_POSTGRESQL_SCHEMA);
    const fixture = readFileSync(new URL('../../ai-tasks/src/ai-task.integration.spec.ts', import.meta.url), 'utf8');
    await db.exec(fixture.match(/const WALLET_SQL = `([\s\S]*?)`;/)![1]!);
    const adapt = (connection: any) => ({ query: (sql: string, values?: readonly unknown[]) => connection.query(sql, values ? [...values] : []) });
    let fetchSignal: AbortSignal | undefined;
    let fetchStarted!: () => void;
    const started = new Promise<void>(resolve => { fetchStarted = resolve; });
    const provider = new FakeMediaProvider({ defaultStep: { mode: 'sync', outputKind: 'url' } });
    const tasks = new AITaskService({
      transactions: { runInTransaction: work => db.transaction(tx => work(adapt(tx))) },
      holds: { place: async () => {}, confirm: async () => {}, release: async () => {} },
      costs: { resolve: () => 0 }, outputs: { put: async () => ({ storageKey: 'test.png' }) },
      providers: { resolve: () => ({ provider, config: {} }) },
      polling: { maxWaitMs: { image: 50 } },
      fetch: async (_url, init) => {
        fetchSignal = init!.signal!;
        fetchStarted();
        return new Promise((_resolve, reject) => { fetchSignal!.addEventListener('abort', () => reject(fetchSignal!.reason), { once: true }); });
      },
    });
    const { task } = await tasks.submitAndWake({ ownerId: 'review-user', kind: 'image', providerId: 'fake-media', model: 'fake-image', input: { prompt: 'test' }, idempotencyKey: 'review-hang-0001' });
    const runtime = new DurableWorkerRuntime({ repository: new PostgresTaskRepository(adapt(db)), resolveHandler: () => tasks.handler,
      retryPolicy: new ExponentialTaskRetryPolicy(), classifyError: () => ({ code: 'INTERNAL', category: 'INTERNAL', summary: 'test', retryable: true }), workerId: 'review-worker' });
    const controller = new AbortController();
    const running = runtime.run(task.id, { signal: controller.signal }).catch(error => error);
    await started;
    await new Promise(resolve => setTimeout(resolve, 150));
    const row = (await db.query('SELECT a."deadlineAt", j.status, j.stage FROM ai_tasks a JOIN async_jobs j USING (id)')).rows[0] as any;
    expect(Date.now()).toBeGreaterThan(new Date(row.deadlineAt).getTime());
    expect(row.status).toBe('PROCESSING');
    expect(row.stage).toBe('storing');
    expect(fetchSignal!.aborted).toBe(false);
    controller.abort();
    await running;
  } finally { await db.close(); }
});
