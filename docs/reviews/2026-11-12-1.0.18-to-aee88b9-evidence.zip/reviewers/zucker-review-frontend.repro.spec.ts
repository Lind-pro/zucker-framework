import axios, { AxiosError } from 'axios';
import { afterEach, expect, it, vi } from 'vitest';
import { shellClient, readCreditBalance } from '../../../templates/web/src/lib/site/session';
import { useAuthStore } from '../../../templates/web/src/lib/stores/auth-store';
import { POST } from '../../../templates/web/src/app/api/revalidate/route';

afterEach(() => { vi.restoreAllMocks(); useAuthStore.getState().logout(); });
const jwt = (sub: string, sid: string) => `h.${btoa(JSON.stringify({ sub, sid }))}.s`;
it('reproduces cross-account refresh adopted by web shell while prior identity remains', async () => {
  const tokenA = jwt('alice', 'session-a'), tokenB = jwt('bob', 'session-b');
  useAuthStore.getState().setAuthState({ token: tokenA, user: { id: 'alice', username: 'alice' } });
  // Another tab signed in as Bob, so its HttpOnly cookie is now the origin cookie.
  vi.spyOn(axios, 'post').mockResolvedValue({ status: 200, data: { access_token: tokenB } });
  const observed: string[] = [];
  shellClient.getAxiosInstance().defaults.adapter = async config => {
    const auth = String(config.headers.get('Authorization'));
    observed.push(auth);
    const response = { config, status: 200, statusText: 'OK', headers: {}, data: { available: 987 } };
    if (auth === `Bearer ${tokenA}`) throw new AxiosError('Expired', 'ERR_BAD_REQUEST', config, undefined, { ...response, status: 401 });
    return response;
  };
  expect(await readCreditBalance()).toBe(987);
  expect(observed).toEqual([`Bearer ${tokenA}`, `Bearer ${tokenB}`]);
  expect(useAuthStore.getState().user?.id).toBe('alice');
  expect(useAuthStore.getState().token).toBe(tokenB);
});

it('reproduces revalidate consuming the entire oversized unsigned chunked body', async () => {
  const saved = process.env.REVALIDATE_SECRET;
  process.env.REVALIDATE_SECRET = 'synthetic-review-secret-01234567890123456789';
  let readBytes = 0;
  const stream = new ReadableStream({
    pull(controller) {
      if (readBytes >= 1024 * 1024) return controller.close();
      const chunk = new Uint8Array(4096).fill(120);
      readBytes += chunk.length;
      controller.enqueue(chunk);
    },
  });
  try {
    const request = new Request('http://localhost/api/revalidate', { method: 'POST', body: stream, duplex: 'half' } as RequestInit);
    const response = await POST(request);
    expect(response.status).toBe(413);
    expect(readBytes).toBe(1024 * 1024);
  } finally {
    if (saved === undefined) delete process.env.REVALIDATE_SECRET;
    else process.env.REVALIDATE_SECRET = saved;
  }
});
