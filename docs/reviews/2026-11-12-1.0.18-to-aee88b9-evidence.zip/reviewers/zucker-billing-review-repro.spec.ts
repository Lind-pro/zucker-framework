import { expect, it, vi } from 'vitest';
import { EventEmitter } from 'node:events';
import { HotProvider } from './hot-apply';
import { PaymentCredentialResolver } from '../billing/payment-credentials';

it('review repro: abort before middleware provider acquisition leaks its lease', async () => {
  let finish!: (value: { id: string }) => void;
  const pending = new Promise<{ id: string }>(resolve => { finish = resolve; });
  const dispose = vi.fn();
  const hot = HotProvider.create(undefined, {}, { name: 'synthetic', profiles: ['mail'], build: () => pending, dispose });
  const response = new EventEmitter();
  const next = vi.fn();
  hot.middleware()({}, response, next);
  response.emit('close');
  finish({ id: 'provider' });
  await vi.waitFor(() => expect(next).toHaveBeenCalledTimes(1));
  await hot.close();
  expect(dispose).toHaveBeenCalledTimes(1);
});

it('review repro: revision 0 orders must retain their payment environment mode', async () => {
  const base = { MODE: 'test', SCOPE: 'account-a', SECRET: 'old' };
  const live = { MODE: 'live', SCOPE: 'account-a', SECRET: 'new' };
  const settings = { runtime: { base }, currentRevision: async () => 1,
    revisions: async () => [{ revision: 1, createdAt: new Date() }],
    environmentAt: async () => live };
  const factory = (env: typeof base) => ({ checkout: { id: 'stripe', accountScope: env.SCOPE, mode: env.MODE } });
  const resolver = new PaymentCredentialResolver(settings, { profiles: { stripe: { profileId: 'payment-stripe', modeKey: 'MODE', scopeKey: 'SCOPE', webhookKeys: ['SECRET'] } }, factory: factory as never });
  const selected = await resolver.forOrder({ providerId: 'stripe', accountScope: 'account-a', configRevision: 'payment-stripe@0' } as never);
  expect((selected as unknown as {mode:string}).mode).toBe('test');
});
