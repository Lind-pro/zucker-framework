import { defineConfig } from 'vitest/config';
import { resolve } from 'node:path';
import base from './vitest.config';
export default defineConfig({
  ...base,
  resolve: { ...base.resolve, alias: [...(base.resolve!.alias as any[]), { find: '@', replacement: resolve('templates/web/src') }] },
  test: { ...base.test, include: ['packages/fe-http-client/src/review-frontend.repro.spec.ts'], maxWorkers: 1 },
});
