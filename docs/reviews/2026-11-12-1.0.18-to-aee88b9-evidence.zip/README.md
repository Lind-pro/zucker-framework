# Review evidence: 0de37ac^..aee88b9, 2026-11-12

This is an evidence snapshot, not a release bundle. No probes call paid providers.
See the adjacent Markdown report for final classification and environment limits.
Red invariant tests demonstrate a defect; green probes may assert that defective
behavior was observed. Neither means the issue was fixed. Full logs include
failed environment setup and discarded candidates.

Temporary probe original locations (relative imports are intentionally preserved):
- root/file-stream-repro.spec.ts -> packages/storage/src/review-root-file-stream.spec.ts
- root/review-root.config.ts -> .review-root.config.ts
- infrastructure/repros.spec.ts -> .review-infrastructure.spec.ts (see its config)
- infrastructure/buffer-repro.spec.ts -> .review-infrastructure.spec.ts (separate run)
- auth repro -> packages/back-office/src/accounts/review-auth-repro.spec.ts
- billing repro -> packages/back-office/src/settings/review-billing-repro.spec.ts
- refund repro -> packages/payment/src/plans/review-refund-repro.spec.ts
- pending repro -> packages/back-office/src/subscriptions/review-pending-repro.spec.ts
- AI runtime repro -> packages/task/src/__review_ai_runtime.spec.ts
- frontend repro -> packages/fe-http-client/src/review-frontend.repro.spec.ts
- reviewer config files -> repository root, adjusting include only if needed.

Typical invocation:
pnpm_config_verify_deps_before_run=false pnpm exec vitest run <original-probe-path> --maxWorkers=1
Some probes require the supplied temporary config to resolve already-installed
Nest dependencies or the Web @ alias. Do not replace normal project config.
Do not run repository mutations, dependency installs, live DB tests or production
builds merely to replay this archive. Use an appropriately prepared test workspace.

PGlite probes exercise actual SQL with synthetic in-memory data, not production
PostgreSQL multi-connection behavior. Redis/cache probes use synthetic ports.
Browser and listening HTTP fixtures were blocked by the runtime sandbox.

The initial pnpm freshness check attempted install but aborted without replacing
node_modules. Turbo lint unexpectedly triggered dependency builds and was stopped;
its partial output is retained. No artifact release was performed. The subsequent
Web lint uses its own ESLint 9 binary; the earlier root ESLint 10 attempt is not a
Web package failure. Root source supplemental logs include four provisional auth
probes; the unsupported wildcard candidate was discarded and is not a finding.
